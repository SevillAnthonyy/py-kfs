import time
from . import console
from . import snapshots_
from . import restart_device_
from . import restart_network_
from . import import_
from . import fwupdate_
from . import mnt_mode_
from . import mnt_adjustment_
from . import panel_note_
from . import device_settings_

def snapshots(driver, count):
    console.log('> Executing snapshots')
    snapshots_.execute(driver, count)

def restart_device(driver, count):
    console.log('> Executing device restart')
    restart_device_.execute(driver, count)

def restart_network(driver, count):
    console.log('> Executing network restart')
    restart_network_.execute(driver, count)

def backupdata_import(driver, count):
    console.log('> Executing import backup data')
    import_.execute(driver, count)

def fwupdate(driver, count):
    console.log('> Executing firmware update')
    fwupdate_.execute(driver, count)

def mnt_mode(driver, count, mode, mm_type):
    console.log('> Executing maintenance mode')
    mnt_mode_.execute(driver, count, mode, mm_type)

def mnt_adjustment(driver, count, mode):
    console.log('> Executing maintenance adjustment settings')
    mnt_adjustment_.execute(driver, count, mode)

def panel_note(driver, count):
    console.log('> Executing panel note')
    panel_note_.execute(driver, count)

def device_settings(driver, count, setting):
    console.log('> Executing device settings')
    device_settings_.execute(driver, count, setting)
